-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: recruiter
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jobpost`
--

DROP TABLE IF EXISTS `jobpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobpost` (
  `post_id` bigint NOT NULL,
  `age_limit` varchar(255) DEFAULT NULL,
  `approved_date` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deadline` date DEFAULT NULL,
  `employee_limit` int DEFAULT NULL,
  `expire_status` int DEFAULT NULL,
  `job_benefit` text,
  `job_category` varchar(255) DEFAULT NULL,
  `job_day` varchar(255) DEFAULT NULL,
  `job_description` text,
  `job_hour` varchar(255) DEFAULT NULL,
  `job_level` varchar(255) DEFAULT NULL,
  `job_location` varchar(255) DEFAULT NULL,
  `job_requirement` text,
  `job_title` varchar(255) DEFAULT NULL,
  `job_type` varchar(255) DEFAULT NULL,
  `max_salary` int DEFAULT NULL,
  `min_salary` int DEFAULT NULL,
  `status` bit(1) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `company_company_id` bigint DEFAULT NULL,
  `payment_payment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `FK9whogeeq7cmilfgy50okrsdq6` (`company_company_id`),
  KEY `FKo5kqc5m2s0olsarchfn4hq2rs` (`payment_payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobpost`
--

LOCK TABLES `jobpost` WRITE;
/*!40000 ALTER TABLE `jobpost` DISABLE KEYS */;
INSERT INTO `jobpost` VALUES (39,'35',NULL,'2021-07-02 00:50:10','2022-05-10',15,NULL,'Great opportunities based on your skill','Administration, business and management','Monday~Friday','To improve administration and to manage Human Resources efficiently.','8:00am~4:00pm','Manager','Mandalay','Better Experience ','Manager','Full Time',NULL,NULL,_binary '\0','2021-07-02 00:50:10',36,38),(40,'25',NULL,'2021-07-02 00:55:10','2021-10-03',20,NULL,'Based on your skill, up to Senior developer','Engineering','Tuesday~Friday','Friendly with Multiple Programming language','9:00am~1:00pm','Entry Level','Yangon','Experience in Java','Developer','Part Time',NULL,NULL,_binary '\0','2021-07-02 00:55:10',36,38),(41,'25',NULL,'2021-07-02 01:00:45','2021-02-01',10,NULL,'If more language skills, salary may higher than expected','Languages','Saturday~Sunday','Movie, Content and News','10:00am~3:00pm','Entry Level','Yangon','Must be influence with English','Translator','Part Time',NULL,NULL,_binary '\0','2021-07-02 01:00:45',36,38),(42,'35',NULL,'2021-07-02 01:06:01','2022-12-31',30,NULL,'More Subscriber, more income.','Performing arts and media','Monday~Friday','Upload 3 or 4 videos in a week.','9:00am~4:30pm','Entry Level','Nay Pyi Thaw','Experience in General Knowledge.\r\nCan Travel through Cities and if needed.','Youtuber','Full Time',NULL,NULL,_binary '\0','2021-07-02 01:06:01',36,38),(43,'25',NULL,'2021-07-02 01:12:26','2022-05-10',25,NULL,'Better salary, if more experience in CCNP or CCIE.','Engineering','Monday~Friday','Network Infrastructure, Troubleshooting, System administration','9:00am~5:00pm','Entry Level','Yangon','Experience in CCNA','Network Engineer','Full Time',NULL,NULL,_binary '\0','2021-07-02 01:12:26',36,38),(53,'35',NULL,'2021-07-02 02:05:18','2023-02-10',5,NULL,'More projects done, more income','Manufacturing and production','Monday~Saturday','Organize well with team members','9:00am~4:00pm','Experienced Non-Manager','Mandalay','Experience in projects and sites','Project Leader','Full Time',NULL,NULL,_binary '\0','2021-07-02 02:05:18',50,52),(54,'25',NULL,'2021-07-02 02:11:16','2023-03-04',20,NULL,'If Products become Best-Selling in the Market.','Print and publishing, marketing and advertising','Monday~Friday','Expect in Marketing and Advertising field','9:00am~3:00pm','Experienced Non-Manager','Yangon','Experience in Product Marketing and Advetisements.','Product Marketing','Full Time',NULL,NULL,_binary '\0','2021-07-02 02:11:16',50,52);
/*!40000 ALTER TABLE `jobpost` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-02  2:13:53
